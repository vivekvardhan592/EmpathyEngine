async function analyzeChat(messages) {
  const response = await fetch("http://127.0.0.1:8000/analyze-chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ messages })
  });

  const data = await response.json();
  return data;
}

document.getElementById("analyzeBtn").addEventListener("click", async () => {

  const rawText = document.getElementById("inputBox").value;
  const messages = rawText.split("\n").filter(m => m.trim() !== "");

  const result = await analyzeChat(messages);

  document.getElementById("tags").innerHTML = "";
  document.getElementById("breakdown").display = "block";
  document.getElementById("trendBox").innerHTML = "";

  // ------------------------------------------------
  // EMOTIONAL TREND — NEW FEATURE
  // ------------------------------------------------
  document.getElementById("trendBox").innerHTML = result.emotional_trend;

  // ------------------------------------------------
  // EMOTION COLORS (FULL SET OF 28 EMOTIONS)
  // ------------------------------------------------
  const emotionColors = {
    admiration: "#6A5ACD", amusement: "#FFB347", anger: "#FF4500",
    annoyance: "#FF6347", approval: "#4B0082", caring: "#DB7093",
    confusion: "#8A2BE2", curiosity: "#20B2AA", desire: "#FF69B4",
    disappointment: "#708090", disapproval: "#A52A2A", disgust: "#556B2F",
    embarrassment: "#CD5C5C", excitement: "#FFA500", fear: "#8B0000",
    gratitude: "#32CD32", grief: "#2F4F4F", joy: "#FFD700",
    love: "#FF1493", nervousness: "#E9967A", optimism: "#00FA9A",
    pride: "#4682B4", realization: "#7B68EE", relief: "#87CEEB",
    remorse: "#8B4513", sadness: "#1E90FF", surprise: "#00CED1",
    neutral: "#604b61ff"
  };

  // ------------------------------------------------
  // GLOBAL EMOTION TAGS (Distribution)
  // ------------------------------------------------
  const distribution = result.emotion_distribution;

  Object.keys(distribution).forEach(emotion => {
    const tag = document.createElement("span");
    const color = emotionColors[emotion] || "#888";
    tag.className = "tag";
    tag.style.borderColor = color;
    tag.style.color = color;
    tag.textContent = `${emotion} (${distribution[emotion]})`;
    document.getElementById("tags").appendChild(tag);
  });

  // ------------------------------------------------
  // MESSAGE-BY-MESSAGE BREAKDOWN
  // ------------------------------------------------
  result.timeline.forEach((item, index) => {
    const div = document.createElement("div");
    div.className = "msgItem";

    const color = emotionColors[item.emotion] || "#888";

    div.innerHTML = `
      <b>${index + 1}. "${item.text}"</b><br>
      Emotion: <span class="emotionLabel" style="background:${color}">${item.emotion}</span>
      <br>

    `;

    document.getElementById("breakdown").appendChild(div);
  });

  // ------------------------------------------------
  // LINE CHART — Emotion Intensity Over Messages
  // ------------------------------------------------
  const ctx = document.getElementById("timelineChart");

  const labels = result.timeline.map((_, i) => `Message ${i + 1}`);
  const dataPoints = result.timeline.map(t => t.score);
  const pointColors = result.timeline.map(t => emotionColors[t.emotion] || "#aaa");

  new Chart(ctx, {
    type: "line",
    data: {
      labels,
      datasets: [{
        label: "Emotion Intensity",
        data: dataPoints,
        borderColor: "#38bdf8",
        borderWidth: 3,
        tension: 0.4,
        pointBackgroundColor: pointColors,
        pointRadius: 6,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: { y: { min: 0, max: 1 } },
      plugins: { legend: { display: false } }
    }
  });

  // ------------------------------------------------
  // PIE CHART — Emotion Distribution
  // ------------------------------------------------
  const pieCtx = document.getElementById("pieChart");

  const pieLabels = Object.keys(distribution);
  const pieValues = Object.values(distribution);
  const pieColors = pieLabels.map(e => emotionColors[e] || "#aaa");

  new Chart(pieCtx, {
    type: "pie",
    data: {
      labels: pieLabels,
      datasets: [{
        data: pieValues,
        backgroundColor: pieColors
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: "bottom",
          labels: { color: "white" }
        }
      }
    }
  });

  // ------------------------------------------------
  // BAR CHART — Emotion Frequency
  // ------------------------------------------------
  const barCtx = document.getElementById("barChart");

  new Chart(barCtx, {
    type: "bar",
    data: {
      labels: pieLabels,
      datasets: [{
        label: "Emotion Count",
        data: pieValues,
        backgroundColor: pieColors,
        borderColor: "#ffffff",
        borderWidth: 1,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: { ticks: { color: "white" } },
        y: { ticks: { color: "white" }, beginAtZero: true }
      },
      plugins: { legend: { display: false } }
    }
  });

});
